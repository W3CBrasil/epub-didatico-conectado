var professor =   {
    "nome": "Clecio Bachini",
    "email": "cbachini@gmail.com"
}

var aluno =   {
    "nome": "Reinaldo Ferraz",
    "email": "reinaldo@nic.br"
}

var xapi ={
    headers: {
        "Content-Type": "application/json",
        "X-Experience-API-Version": "1.0.3",
        "Authorization": "Basic M2QzYTZiNWJkY2UyOWQ3MmIzZGZiYTE1YmJkMGE2N2YxY2FiOWVmNDozZTI4YTRlZDA5ZjRmNDQyNzkxNGZjNmE5ZTJmYTk0N2ZlYjRhN2Fm",
      },
      endpoint: "https://xapi.soyuz.com.br/data/xAPI/statements"
}