import React from 'react';

const NoData = () => (
  <h4 style={{ textAlign: 'center', marginTop: 20, width: '100%' }}>
    No data in this time range.
  </h4>
);

export default NoData;
