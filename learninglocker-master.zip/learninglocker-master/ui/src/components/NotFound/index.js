import React from 'react';

export default function NotFound() {
  return (
    <div className="container">
      <h1>Coming soon!</h1>
      <p>This page is still being built</p>
    </div>
  );
}
