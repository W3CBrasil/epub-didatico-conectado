import styled from 'styled-components';

export default styled.div`
  font-size: 12px;
  padding: 2px 5px;
  justify-content: flex-start;
  word-break: break-word;
`;
