import { PIE_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Pie';
export const image = PIE_IMAGE;
