import { FREQUENCY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Line';
export const image = FREQUENCY_IMAGE;
