import { COUNTER_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Counter';
export const image = COUNTER_IMAGE;
