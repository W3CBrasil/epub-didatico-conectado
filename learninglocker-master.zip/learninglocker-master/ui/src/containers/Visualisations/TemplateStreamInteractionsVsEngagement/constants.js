import { XVSY_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Stream interactions vs engagement (last 7 days)';
export const description = 'Interactions vs Engagement - Last 7 Days';
export const image = XVSY_GREY_IMAGE;
