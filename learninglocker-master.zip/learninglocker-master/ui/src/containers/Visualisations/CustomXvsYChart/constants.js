import { XVSY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Correlation';
export const image = XVSY_IMAGE;
