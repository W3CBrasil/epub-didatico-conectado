import { COUNTER_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Stream comment count (last 7 days)';
export const description = 'Comment Count - Last 7 vs Previous 7';
export const image = COUNTER_GREY_IMAGE;
