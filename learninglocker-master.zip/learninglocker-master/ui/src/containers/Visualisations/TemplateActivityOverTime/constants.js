import { FREQUENCY_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'How has activity changed over time?';
export const description = 'How has activity changed over time?';
export const image = FREQUENCY_GREY_IMAGE;
