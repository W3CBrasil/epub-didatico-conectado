import { COUNTER_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'How many statements have been stored in the last 7 days?';
export const description = 'How many statements have been stored in the last 7 days?';
export const image = COUNTER_GREY_IMAGE;
