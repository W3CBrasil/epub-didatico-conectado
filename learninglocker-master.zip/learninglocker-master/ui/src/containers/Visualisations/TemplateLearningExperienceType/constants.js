import { LEADERBOARD_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'What are the most popular learning experience activity types?';
export const description = 'What are the most popular learning experience activity types?';
export const image = LEADERBOARD_GREY_IMAGE;
