import { LEADERBOARD_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'What are the most popular verbs?';
export const description = 'What are the most popular verbs?';
export const image = LEADERBOARD_GREY_IMAGE;
