import { LEADERBOARD_GREY_IMAGE } from 'ui/components/VisualiseIcon/assets';

export const title = 'Who are the most active people?';
export const description = 'Who are the most active people?';
export const image = LEADERBOARD_GREY_IMAGE;
