# To add a migration

Create the file in this directory.
Add the file to index.js dependencies and exported List.


